import { ChildProcessWithoutNullStreams } from "child_process";
export declare function getDockerNetworkGateway(): Promise<string[]>;
export declare function ipconfig(): Promise<string[]>;
export declare function avahiResolve(ip: string): Promise<string | undefined>;
export declare function dig(ip: string): Promise<string | undefined>;
export declare function commandReturn(cmd: string): Promise<boolean>;
export declare function pingOneShot(ipOrHostName: string): Promise<boolean>;
export declare function sshIsRunning(ipOrHostName: string, sshPort?: number): Promise<boolean>;
export declare function spawnWindowsUdpListener(port: number): ChildProcessWithoutNullStreams;
export interface UdpDatagram {
    senderIp?: string;
    payload: string;
}
export declare function listenWindowsUdp(port: number, timeoutMs: number, onDatagram: (datagram: UdpDatagram) => void): Promise<UdpDatagram[]>;
