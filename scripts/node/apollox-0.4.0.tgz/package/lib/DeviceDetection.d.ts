import { TorizonDevice } from "./interfaces/TorizonDevice";
import { NetworkDevice } from "./interfaces/NetworkDevice";
export declare class DeviceDetection {
    NewDeviceFoundCallback: (device: NetworkDevice) => void;
    constructor(callback: (device: NetworkDevice) => void);
    ScanDevices(): Promise<NetworkDevice[]>;
    private static _hostNameIsIp;
    static GetNetworkDevices(_deviceFoundCallback?: (device: NetworkDevice) => void): Promise<NetworkDevice[]>;
    private static readonly PHOBOS_UDP_PORT;
    private static readonly PHOBOS_CLIENT_NAME;
    private static _parsePhobOSMessage;
    static GetPhobOSDevices(_deviceFoundCallback?: (device: NetworkDevice) => void, timeoutMs?: number): Promise<NetworkDevice[]>;
    private static _getPhobOSDevicesLocal;
    private static _getPhobOSDevicesViaWindows;
    static ConnectToDevice(netDev: NetworkDevice, user: string, pswd: string, hostIp?: string, port?: number, restartDocker?: boolean): Promise<TorizonDevice | undefined>;
}
